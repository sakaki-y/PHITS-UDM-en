../../../phits_MacGfort-udm-1.0 < main.inp
