../../../phits_MacIfort-udm < main.inp
